<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Python + Streamlit Data Science Bootcamp</title>
  <meta name="description" content="Join the 5‑Day Python + Streamlit Data Science Bootcamp. Build projects, deploy your app, get certificate + recordings. Early bird ₹1,499."/>
  <meta property="og:title" content="Python + Streamlit Data Science Bootcamp"/>
  <meta property="og:description" content="5 days • 3 hours/day • Projects • Deployment • Certificate"/>
  <meta property="og:type" content="website"/>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <!-- Tailwind via CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root { --brand:#2457F5; --brand-2:#0EA5E9; }
    body { font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji", "Segoe UI Emoji"; }
    .glass { backdrop-filter: blur(8px); background: rgba(255,255,255,.7); }
    .shadow-soft { box-shadow: 0 10px 30px rgba(2,6,23,.1); }
    .check::before{content:"✔"; margin-right:.5rem}
    .badge{display:inline-flex;align-items:center;gap:.4rem;padding:.35rem .6rem;border-radius:9999px;background:#eef2ff;color:#3730a3;font-weight:600;font-size:.78rem}
    .grad{background:linear-gradient(135deg,var(--brand),#8b5cf6)}
    .grad-text{background:linear-gradient(90deg,var(--brand),var(--brand-2));-webkit-background-clip:text;background-clip:text;color:transparent}
    .faq-item[open] summary svg{transform:rotate(180deg)}
  </style>
</head>
<body class="bg-slate-50 text-slate-800">
  <!-- Sticky mobile bar -->
  <div class="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t border-slate-200 p-3 flex items-center justify-between gap-3">
    <div class="text-sm">
      <div class="font-semibold">Early Bird: <span class="text-emerald-600">₹1,499</span></div>
      <div class="text-slate-500">Ends soon • Limited seats</div>
    </div>
    <a href="#register" class="px-4 py-2 rounded-xl text-white grad shadow-soft font-semibold">Register</a>
  </div>

  <!-- Nav -->
  <header class="sticky top-0 z-30 bg-white/80 glass border-b border-slate-200">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <span class="w-9 h-9 rounded-2xl grad inline-flex items-center justify-center text-white font-black">Py</span>
        <span class="font-extrabold text-slate-800">Python + Streamlit Bootcamp</span>
      </div>
      <nav class="hidden md:flex items-center gap-6 text-sm">
        <a href="#curriculum" class="hover:text-slate-900 text-slate-600">Curriculum</a>
        <a href="#projects" class="hover:text-slate-900 text-slate-600">Projects</a>
        <a href="#instructor" class="hover:text-slate-900 text-slate-600">Instructor</a>
        <a href="#faq" class="hover:text-slate-900 text-slate-600">FAQ</a>
        <a href="#register" class="px-4 py-2 rounded-xl text-white grad shadow-soft font-semibold">Register</a>
      </nav>
    </div>
  </header>

  <!-- Hero -->
  <section class="relative overflow-hidden">
    <div class="absolute inset-0 grad opacity-10"></div>
    <div class="max-w-6xl mx-auto px-4 sm:px-6 py-14 md:py-20 grid md:grid-cols-2 gap-10 items-center">
      <div>
        <div class="mb-4 flex flex-wrap gap-2">
          <span class="badge">5 days</span>
          <span class="badge">3 hours/day</span>
          <span class="badge">Live + Recording</span>
          <span class="badge">Certificate</span>
        </div>
        <h1 class="text-3xl sm:text-5xl font-extrabold leading-tight">
          Build & Deploy <span class="grad-text">Data Science Apps</span> with <span class="grad-text">Python + Streamlit</span>
        </h1>
        <p class="mt-4 text-slate-600 text-lg">Hands-on bootcamp where you analyse real datasets, train ML models, and deploy a polished Streamlit app — ready for your portfolio.</p>
        <div class="mt-6 flex items-center gap-4">
          <a href="#register" class="px-5 py-3 rounded-2xl text-white grad shadow-soft font-semibold">Register Now</a>
          <a href="#curriculum" class="px-5 py-3 rounded-2xl border border-slate-300 hover:border-slate-400">See Curriculum</a>
        </div>
        <p class="mt-4 text-sm text-slate-500">Starts immediately after the free workshop • Limited seats</p>
      </div>
      <div class="relative">
        <div class="rounded-3xl shadow-soft bg-white p-4 md:p-6 border border-slate-200">
          <img src="https://images.unsplash.com/photo-1556157382-97eda2d62296?q=80&w=1400&auto=format&fit=crop" alt="Data dashboard" class="rounded-2xl w-full object-cover">
          <div class="mt-4 grid grid-cols-3 gap-3 text-sm">
            <div class="p-3 bg-slate-100 rounded-xl text-center">
              <div class="font-bold">₹1,499</div><div class="text-slate-500">Early Bird</div>
            </div>
            <div class="p-3 bg-slate-100 rounded-xl text-center">
              <div class="font-bold">15 hrs</div><div class="text-slate-500">Live Training</div>
            </div>
            <div class="p-3 bg-slate-100 rounded-xl text-center">
              <div class="font-bold">5 Projects</div><div class="text-slate-500">Portfolio Ready</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- What you'll learn -->
  <section id="projects" class="py-14 bg-white">
    <div class="max-w-6xl mx-auto px-4 sm:px-6">
      <h2 class="text-2xl sm:text-3xl font-extrabold mb-6">What you will build</h2>
      <div class="grid md:grid-cols-3 gap-6">
        <div class="p-6 bg-slate-50 rounded-2xl border border-slate-200">
          <div class="font-semibold mb-2">Interactive EDA Dashboard</div>
          <p class="text-sm text-slate-600">Upload CSVs, explore stats, filters, and charts with Streamlit widgets.</p>
        </div>
        <div class="p-6 bg-slate-50 rounded-2xl border border-slate-200">
          <div class="font-semibold mb-2">ML Classifier App</div>
          <p class="text-sm text-slate-600">Train & evaluate models (Logistic Regression / Tree) and expose predictions.</p>
        </div>
        <div class="p-6 bg-slate-50 rounded-2xl border border-slate-200">
          <div class="font-semibold mb-2">Deployed Portfolio App</div>
          <p class="text-sm text-slate-600">Push to GitHub and deploy on Streamlit Cloud with a shareable link.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Curriculum -->
  <section id="curriculum" class="py-14">
    <div class="max-w-6xl mx-auto px-4 sm:px-6">
      <h2 class="text-2xl sm:text-3xl font-extrabold mb-6">5‑Day Curriculum (3 hours/day)</h2>
      <div class="grid md:grid-cols-2 gap-6">
        <div class="p-6 rounded-2xl border border-slate-200 bg-white">
          <div class="font-bold mb-2">Day 1 — Python & Pandas</div>
          <ul class="list-disc pl-5 text-sm text-slate-600 space-y-1">
            <li>Python refresher, NumPy & Pandas essentials</li>
            <li>Data cleaning, joins, groupby, simple EDA</li>
          </ul>
        </div>
        <div class="p-6 rounded-2xl border border-slate-200 bg-white">
          <div class="font-bold mb-2">Day 2 — Visualization</div>
          <ul class="list-disc pl-5 text-sm text-slate-600 space-y-1">
            <li>Matplotlib & Seaborn patterns</li>
            <li>Insightful plots & mini dashboard</li>
          </ul>
        </div>
        <div class="p-6 rounded-2xl border border-slate-200 bg-white">
          <div class="font-bold mb-2">Day 3 — ML Fundamentals</div>
          <ul class="list-disc pl-5 text-sm text-slate-600 space-y-1">
            <li>Train/test split, model training</li>
            <li>Accuracy, confusion matrix, metrics</li>
          </ul>
        </div>
        <div class="p-6 rounded-2xl border border-slate-200 bg-white">
          <div class="font-bold mb-2">Day 4 — Streamlit App</div>
          <ul class="list-disc pl-5 text-sm text-slate-600 space-y-1">
            <li>Widgets, layouts, file uploader</li>
            <li>Connect model + interactive UI</li>
          </ul>
        </div>
        <div class="p-6 rounded-2xl border border-slate-200 bg-white md:col-span-2">
          <div class="font-bold mb-2">Day 5 — Deploy & Showcase</div>
          <ul class="list-disc pl-5 text-sm text-slate-600 space-y-1">
            <li>Multi-page apps, tips for speed & UX</li>
            <li>Deploy on Streamlit Cloud + portfolio review</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <!-- Pricing -->
  <section id="register" class="py-14 bg-white">
    <div class="max-w-6xl mx-auto px-4 sm:px-6">
      <h2 class="text-2xl sm:text-3xl font-extrabold mb-6">Registration</h2>
      <div class="grid md:grid-cols-3 gap-6">
        <div class="p-6 rounded-2xl border border-slate-200 bg-slate-50">
          <div class="text-slate-500 text-sm mb-1">Early Bird</div>
          <div class="text-4xl font-extrabold">₹1,499</div>
          <p class="text-sm text-slate-600 mt-2">Valid till midnight after the free workshop.</p>
          <a href="https://rzp.io/l/your-payment-link" class="mt-4 block text-center px-4 py-3 rounded-xl text-white grad shadow-soft font-semibold">Pay & Register</a>
        </div>
        <div class="p-6 rounded-2xl border border-slate-200 bg-white">
          <div class="text-slate-500 text-sm mb-1">Regular</div>
          <div class="text-4xl font-extrabold">₹1,999</div>
          <p class="text-sm text-slate-600 mt-2">Applies from the next morning.</p>
          <a href="https://rzp.io/l/your-payment-link" class="mt-4 block text-center px-4 py-3 rounded-xl text-white grad shadow-soft font-semibold">Pay & Register</a>
        </div>
        <div class="p-6 rounded-2xl border border-slate-200 bg-white">
          <div class="text-slate-500 text-sm mb-1">Need Help?</div>
          <div class="text-2xl font-bold">Talk to us</div>
          <p class="text-sm text-slate-600 mt-2">Have questions about the curriculum or schedule?</p>
          <a href="https://wa.me/91XXXXXXXXXX?text=I%20want%20to%20join%20the%20Python%20%2B%20Streamlit%20Bootcamp" class="mt-4 block text-center px-4 py-3 rounded-xl border border-slate-300 hover:border-slate-400 font-semibold">Chat on WhatsApp</a>
        </div>
      </div>
      <p class="mt-4 text-sm text-slate-500">Includes certificate, recordings, code repos & lifetime community access.</p>
    </div>
  </section>

  <!-- Instructor -->
  <section id="instructor" class="py-14">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 grid md:grid-cols-3 gap-8 items-center">
      <div class="md:col-span-2">
        <h2 class="text-2xl sm:text-3xl font-extrabold mb-4">Meet your instructor</h2>
        <p class="text-slate-600">Freelance Technical Trainer with corporate and college experience, building data apps and mentoring learners. Delivered 1000+ hours of live training across Python, Data Science and Cloud.</p>
        <ul class="mt-4 text-sm text-slate-700 space-y-2">
          <li class="check">Real‑world datasets & case studies</li>
          <li class="check">Job‑ready projects for your portfolio</li>
          <li class="check">Interview pointers & career guidance</li>
        </ul>
      </div>
      <div>
        <div class="rounded-2xl overflow-hidden border border-slate-200 bg-white shadow-soft p-4 text-center">
          <img class="rounded-xl w-full object-cover" src="https://images.unsplash.com/photo-1600880292089-90e7e86c0b56?q=80&w=1200&auto=format&fit=crop" alt="Instructor"/>
          <div class="mt-3 font-semibold">Your Name</div>
          <div class="text-xs text-slate-500">Trainer • Data App Developer</div>
        </div>
      </div>
    </div>
  </section>

  <!-- FAQ -->
  <section id="faq" class="py-14 bg-white">
    <div class="max-w-6xl mx-auto px-4 sm:px-6">
      <h2 class="text-2xl sm:text-3xl font-extrabold mb-6">Frequently asked questions</h2>
      <div class="space-y-3">
        <details class="faq-item p-5 bg-slate-50 rounded-xl border border-slate-200">
          <summary class="flex items-center justify-between cursor-pointer font-semibold">Is this beginner friendly?
            <svg class="w-5 h-5 text-slate-500 transition-transform" viewBox="0 0 20 20" fill="currentColor"><path d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z"/></svg>
          </summary>
          <p class="mt-3 text-sm text-slate-600">Yes. We start with Python & Pandas basics and quickly move to hands‑on projects. Helpful for both beginners and upskilling professionals.</p>
        </details>
        <details class="faq-item p-5 bg-slate-50 rounded-xl border border-slate-200">
          <summary class="flex items-center justify-between cursor-pointer font-semibold">Will I get recordings & certificate?
            <svg class="w-5 h-5 text-slate-500 transition-transform" viewBox="0 0 20 20" fill="currentColor"><path d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z"/></svg>
          </summary>
          <p class="mt-3 text-sm text-slate-600">Absolutely. You’ll receive lifetime access to session recordings, code notebooks, and a digital certificate upon completion.</p>
        </details>
        <details class="faq-item p-5 bg-slate-50 rounded-xl border border-slate-200">
          <summary class="flex items-center justify-between cursor-pointer font-semibold">Do I need prior ML knowledge?
            <svg class="w-5 h-5 text-slate-500 transition-transform" viewBox="0 0 20 20" fill="currentColor"><path d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z"/></svg>
          </summary>
          <p class="mt-3 text-sm text-slate-600">No. We cover the essentials needed to build, evaluate, and deploy a simple ML model.</p>
        </details>
      </div>
    </div>
  </section>

  <footer class="py-10">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-500">
      <div>© <span id="year"></span> Python + Streamlit Bootcamp</div>
      <div class="flex items-center gap-4">
        <a class="underline" href="mailto:you@example.com">you@example.com</a>
        <a class="underline" href="https://wa.me/91XXXXXXXXXX">WhatsApp</a>
      </div>
    </div>
  </footer>

  <script>
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(a=>{
      a.addEventListener('click',e=>{ const id=a.getAttribute('href'); if(id.length>1){ e.preventDefault(); document.querySelector(id).scrollIntoView({behavior:'smooth'});} });
    });
    // Year
    document.getElementById('year').textContent = new Date().getFullYear();
  </script>
</body>
</html>
