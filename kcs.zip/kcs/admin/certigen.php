<?php
require('fpdf/fpdf.php');

class PDF extends FPDF {
    function Header() {
        // Background certificate template
        $this->Image('certi.png', 0, 0, 297, 210); // A4 Landscape
    }
}

// Example: Preview for one participant
$participantName = "Sivarama krishnan v";

$pdf = new PDF('L', 'mm', 'A4');
$pdf->AddPage();

// Font settings for Name
$pdf->SetFont('Times', 'B', 28);
$pdf->SetTextColor(0, 51, 102);

// Print Name (center)
$pdf->SetXY(0, 100);
$pdf->Cell(297, 5, $participantName, 0, 1, 'C');

// // Participation line
// $pdf->SetFont('Times', '', 20);
// $pdf->SetXY(0, 130);
// $pdf->Cell(297, 10, "has successfully participated in", 0, 1, 'C');

// // Workshop Title
// $pdf->SetFont('Times', 'B', 22);
// $pdf->SetTextColor(200, 0, 0);
// $pdf->SetXY(0, 145);
// $pdf->Cell(297, 12, "Python with Data Science & Streamlit", 0, 1, 'C');

 $pdf->SetFont('Times', 'B', 22);
 $pdf->SetTextColor(200, 0, 0);
 $pdf->SetXY(0, 177);
 $pdf->Cell(160, 12, "kcs25260001", 0, 1, 'C');
// Show certificate in browser
$pdf->Output('I', 'certificate_preview.pdf');
?>
