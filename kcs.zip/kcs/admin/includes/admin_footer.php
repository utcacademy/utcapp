  </div> <!-- container -->
  <footer class="text-center py-3 mt-4" style="background:#f8f9fa;">
    <p class="mb-0">&copy; <?php echo date("Y"); ?> Kovai Consultancy Services - Admin Panel</p>
  </footer>
</body>
</html>
