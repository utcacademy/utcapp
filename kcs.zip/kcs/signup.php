<?php
session_start();
include 'db.php';

if(isset($_POST['signup'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check email exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    if($stmt->get_result()->num_rows > 0){
        $error = "Email already registered";
    } else {
        $stmt = $conn->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");
        $stmt->bind_param("sss",$name,$email,$password);
        $stmt->execute();
        $_SESSION['user_id'] = $conn->insert_id;
        $_SESSION['name'] = $name;
        $redirect = isset($_GET['redirect']) ? $_GET['redirect'] : "dashboard.php";
        if(isset($_GET['id'])) $redirect .= "?id=".$_GET['id'];
        header("Location:$redirect");
        exit;
    }
}
?>

<?php include('includes/header.php'); ?>
<section class="container py-5">
<h2>Sign Up</h2>
<?php if(isset($error)) echo "<p class='text-danger'>$error</p>"; ?>
<form method="post">
  <input type="text" name="name" class="form-control mb-2" placeholder="Full Name" required>
  <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
  <input type="password" name="password" class="form-control mb-2" placeholder="Password" required>
  <button type="submit" name="signup" class="btn btn-primary">Sign Up</button>
</form>
<p class="mt-2">Already have an account? <a href="login.php">Login here</a></p>
</section>
<?php include('includes/footer.php'); ?>
