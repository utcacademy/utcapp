<?php
session_start();
include 'db.php';
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];
?>

<?php include('includes/header.php'); ?>
<section class="container py-5">
<h2>Welcome, <?php echo $_SESSION['name']; ?></h2>
<h4>Your Registered Workshops</h4>
<div class="row g-4">
<?php
$sql = "SELECT w.* FROM workshops1 w 
        JOIN registrations r ON w.id=r.workshop_id
        WHERE r.user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$user_id);
$stmt->execute();
$res = $stmt->get_result();
if($res->num_rows > 0){
    while($row = $res->fetch_assoc()){
        echo '<div class="col-md-6">
        <div class="p-3 bg-dark text-white rounded-3">
          <h5>'.$row['title'].'</h5>
          <p><strong>Date:</strong> '.date("d M Y",strtotime($row['date'])).'</p>
          <p><strong>Time:</strong> '.date("h:i A",strtotime($row['time'])).'</p>
        </div></div>';
    }
} else {
    echo '<p>You have not registered for any workshops yet.</p>';
}
?>
</div>
</section>
<?php include('includes/footer.php'); ?>
