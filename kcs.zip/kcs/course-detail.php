<?php
include 'db.php';

if(!isset($_GET['id']) || empty($_GET['id'])){
    header("Location: courses.php");
    exit();
}

$course_id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT * FROM courses1 WHERE id = ?");
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows == 0){
    echo "<p class='text-center mt-5'>Course not found.</p>";
    exit();
}

$course = $result->fetch_assoc();
?>
<?php include('includes/header.php');?>

<style>

.course-detail { background: #1e293b; border-radius: 12px; padding: 2rem; margin-top: 2rem; }
.course-detail h2 { margin-bottom: 1rem; }
.btn-primary { background: #22d3ee; border: none; border-radius: 50px; font-weight: 600; }
.btn-primary:hover { background: #06b6d4; }

  </style>

<!-- Course Detail -->
<section class="container">
  <div class="course-detail">
    <h2><?php echo htmlspecialchars($course['title']); ?></h2>
    <p><strong>Duration:</strong> <?php echo htmlspecialchars($course['duration']); ?></p>
    <p><strong>Fee:</strong> ₹<?php echo number_format($course['fee'], 2); ?></p>
    <p><?php echo nl2br(htmlspecialchars($course['description'])); ?></p>
    <a href="courses.php" class="btn btn-primary mt-3">Back to Courses</a>
  </div>
</section>
  <br/><br/>  <br/><br/>
<?php include('includes/footer.php');?>